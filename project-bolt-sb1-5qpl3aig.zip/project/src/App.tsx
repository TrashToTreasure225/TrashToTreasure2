import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import VideoSection from './components/VideoSection';
import TransparencyDashboard from './components/TransparencyDashboard';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import './styles/animations.css';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <About />
      <VideoSection />
      <TransparencyDashboard />
      <Gallery />
      <Footer />
    </div>
  );
}

export default App;