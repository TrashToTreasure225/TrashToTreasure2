import React from 'react';
import { Recycle, Leaf, DollarSign, Factory } from 'lucide-react';

interface AboutCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  step: number;
}

const AboutCard: React.FC<AboutCardProps> = ({ icon, title, description, step }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:translate-y-[-5px] border-t-4 border-green-500">
      <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-green-600">
        {icon}
      </div>
      <div className="absolute -top-3 -left-3 bg-green-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
        {step}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const About: React.FC = () => {
  const cards = [
    {
      icon: <Recycle size={24} />,
      title: 'Waste Sorting',
      description: 'Students sort organic and inorganic waste at collection points throughout their school.',
      step: 1,
    },
    {
      icon: <Leaf size={24} />,
      title: 'Organic Processing',
      description: 'Organic waste is delivered to maggot (BSF) farms for natural decomposition and fertilizer production.',
      step: 2,
    },
    {
      icon: <DollarSign size={24} />,
      title: 'Weekly Sales',
      description: 'Inorganic waste is cleaned, sorted, and sold weekly to recycling facilities, generating income.',
      step: 3,
    },
    {
      icon: <Factory size={24} />,
      title: 'Fund Collection',
      description: 'Each participating school contributes Rp10,000/week towards purchasing an RDF/pyrolysis machine.',
      step: 4,
    },
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">About the Program</h2>
          <div className="w-20 h-1 bg-green-500 mx-auto mb-6"></div>
          <p className="text-gray-600 text-lg">
            Our student-led initiative transforms school waste management through a systematic approach 
            that creates environmental and economic benefits.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connection line between cards (desktop only) */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-green-200 z-0"></div>
          
          {cards.map((card, index) => (
            <div key={index} className="relative z-10">
              <AboutCard {...card} />
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-gray-700 max-w-3xl mx-auto bg-green-50 p-6 rounded-lg border-l-4 border-green-500 shadow-sm">
            <strong>Our Vision:</strong> Through this collaborative effort, we aim to create a sustainable 
            waste management system that reduces landfill waste, provides educational opportunities, 
            and ultimately leads to the purchase of advanced recycling technology for our community.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;