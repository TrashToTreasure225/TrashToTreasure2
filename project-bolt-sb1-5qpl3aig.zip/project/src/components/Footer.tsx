import React from 'react';
import { Instagram, Mail, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-green-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Trash to Treasure</h3>
            <p className="text-green-100 mb-4">
              A youth-led environmental initiative transforming school waste into meaningful impact
              through recycling, education, and community action in Bali.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://instagram.com/trashtotreasure.bali" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-green-200 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={24} />
              </a>
              <a 
                href="mailto:trashtotreasure225@gmail.com" 
                className="text-white hover:text-green-200 transition-colors"
                aria-label="Email"
              >
                <Mail size={24} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {['Home', 'About', 'Video', 'Transparency', 'Gallery'].map(item => (
                <li key={item}>
                  <a 
                    href={`#${item.toLowerCase()}`}
                    className="text-green-100 hover:text-white transition-colors"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <p className="text-green-100 mb-2">
              <strong>Instagram:</strong> @trashtotreasure.bali
            </p>
            <p className="text-green-100 mb-2">
              <strong>Email:</strong> trashtotreasure225@gmail.com
            </p>
            <p className="text-green-100">
              <strong>Location:</strong> Bali, Indonesia
            </p>
          </div>
        </div>
        
        <div className="border-t border-green-700 mt-8 pt-6 text-center">
          <p className="text-green-200 text-sm">
            © {new Date().getFullYear()} Trash to Treasure Initiative. All rights reserved.
          </p>
          <p className="text-green-300 text-sm mt-2 flex items-center justify-center">
            Created with <Heart size={16} className="mx-1 text-red-400" /> by student developers of Bali
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer