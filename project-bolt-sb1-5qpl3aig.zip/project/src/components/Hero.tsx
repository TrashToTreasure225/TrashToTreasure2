import React, { useEffect, useState } from 'react';
import { Leaf, RefreshCw, ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section 
      id="home"
      className="min-h-screen relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-green-700 to-green-600"
    >
      {/* Abstract background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -left-10 top-20 w-40 h-40 md:w-64 md:h-64 rounded-full bg-green-500/20 blur-xl"></div>
        <div className="absolute right-10 top-40 w-32 h-32 md:w-80 md:h-80 rounded-full bg-blue-500/20 blur-xl"></div>
        <div className="absolute bottom-20 left-1/4 w-40 h-40 md:w-56 md:h-56 rounded-full bg-brown-500/20 blur-xl"></div>
        
        {/* Animated leaves */}
        <div className="absolute inset-0">
          {[...Array(10)].map((_, i) => (
            <Leaf
              key={i}
              className="absolute text-green-200/40 animate-float"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                fontSize: `${Math.random() * 2 + 0.5}rem`,
                animationDelay: `${Math.random() * 10}s`,
                animationDuration: `${Math.random() * 20 + 10}s`,
              }}
              size={Math.random() * 40 + 20}
            />
          ))}
        </div>
        
        {/* Recycling icons */}
        {[...Array(5)].map((_, i) => (
          <RefreshCw
            key={i}
            className="absolute text-white/30 animate-spin-slow"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 10}s`,
              animationDuration: `${Math.random() * 30 + 20}s`,
            }}
            size={Math.random() * 30 + 15}
          />
        ))}
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 z-10 text-center">
        <div 
          className={`transition-all duration-1000 transform ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
            Transforming Trash into Treasure
          </h1>
          <h2 className="text-xl md:text-2xl lg:text-3xl text-green-100 mb-8">
            A Student Movement for a Cleaner Bali
          </h2>
          <p className="text-md md:text-lg text-white/90 max-w-2xl mx-auto mb-10">
            Turning waste into progress through youth-led transparency and action.
          </p>
          
          <div className="flex flex-col md:flex-row justify-center gap-4 mt-8">
            <a
              href="#about"
              className="bg-white text-green-700 hover:bg-green-50 font-semibold py-3 px-6 rounded-lg shadow-lg transition transform hover:scale-105"
            >
              Learn More
            </a>
            <a
              href="#transparency"
              className="bg-transparent text-white border-2 border-white hover:bg-white/10 font-semibold py-3 px-6 rounded-lg shadow-lg transition transform hover:scale-105"
            >
              See Our Progress
            </a>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown size={36} className="text-white/70" />
      </div>
    </section>
  );
};

export default Hero;